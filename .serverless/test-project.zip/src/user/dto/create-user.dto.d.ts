export declare class CreateUserDto {
}
